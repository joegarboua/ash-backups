# Monero Wallet -- Ash

## Receive Address

4AFqx1Rxs3tgMuUKFErSaR6LdnmqgAsMGYynZmYV9NmLCKK5Fc8jsD7iC3vBNVDtDvap4kVQ54M2NZEh3gyGF1cTRcCN4Z4

**This is the mining payout address.**

## Key Files

- `secrets/monero.json` (chmod 600) -- seed phrase + all keys
- NEVER expose seed phrase or private keys

## Check Balance

Pool stats: MoneroOcean API with above address (see tools/xmr-stats.py)

## Mining Pool

- Pool: MoneroOcean (gulf.moneroocean.stream:10128)
- Payout threshold: 0.003 XMR (auto-exchange to BTC available)
- No registration needed -- just mine to address

## XMR to BTC Conversion

MoneroOcean supports auto-conversion: register with your address at their site,
set BTC payout address, and payouts arrive in BTC directly.
Alternatively: use FixedFloat or SideShift.ai for manual conversion.
