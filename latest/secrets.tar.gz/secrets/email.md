# Email Credentials — Ash

## Primary Registration Email (Use for domains/registrars)

- **Address:** agent4ivfip@gmx.com
- **Provider:** GMX (https://www.gmx.com)
- **Status:** Identity recorded for signup flows; not re-verified in this session.

## Operations Email (Use for automation/inbox workflows)

- **Address:** ashverify1772851103@dollicons.com
- **Password:** (see `secrets/email.json`)
- **Provider:** Mail.tm (https://api.mail.tm)
- **Created:** 2026-03-07T02:38:24Z
- **Domain:** dollicons.com (public, active)
- **Status:** Last successful verification at 2026-03-07T02:38 UTC (token + inbox).
- **Current session:** Recheck failed at 2026-03-07T02:39:51Z due DNS resolution failure in runtime (`Temporary failure in name resolution`).

> NOTE: mail.tm accounts can expire. Run `tools/refresh-email.py` to create a new one if token login fails.


## API Usage

```python
import urllib.request, json

# Get token
def get_mailbox_token():
    data = json.dumps({'address': 'ashverify1772851103@dollicons.com', 'password': 'READ_FROM_SECRETS_EMAIL_JSON'}).encode()
    req = urllib.request.Request('https://api.mail.tm/token', data=data,
                                  headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())['token']

# Check inbox
def check_inbox(token):
    req = urllib.request.Request('https://api.mail.tm/messages',
                                  headers={'Authorization': f'Bearer {token}'})
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read().decode())
```

## Notes
- Use `tools/refresh-email.py` at the start of any task requiring email — accounts expire.
- Mail.tm is for automation/inbound only. Use for account signups.
- Mail.tm quota: 40MB per account.
