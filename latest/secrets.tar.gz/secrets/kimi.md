# Kimi CLI Credentials — Ash

## Authentication

- **Credentials file:** `~/.kimi/credentials/kimi-code.json`
- **Type:** OAuth 2.0 (device code flow)
- **Client ID:** 17e5f671-d194-4dfb-9706-5516cb48c098
- **Refresh endpoint:** POST https://auth.kimi.com/api/oauth/token
- **Token lifetime:** 900 seconds (15 minutes)
- **Refresh token lifetime:** ~30 days

## Auto-Refresh

Managed by `ash-kimi-refresh.timer` (runs every 10 minutes).
Script: `/home/ash/ASH/daemon/kimi-refresh.py`

## Manual Refresh

```bash
python3 /home/ash/ASH/daemon/kimi-refresh.py
```

## Important Limitations

- Kimi CLI has NO `-p` flag — it is a TUI-only tool (term/web/acp modes)
- Cannot be used as an LLM subprocess like `claude -p`
- Direct API calls to `api.kimi.com/coding/v1` are blocked outside agent contexts
- Error: `access_terminated_error` — "Kimi For Coding is only available for Coding Agents"

## Re-login (if refresh token expires)

```bash
kimi login
# Follow browser URL to authorize
```

## Config

`~/.kimi/config.toml` — default model: kimi-for-coding
