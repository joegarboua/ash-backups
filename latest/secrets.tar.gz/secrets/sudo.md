# Sudo Access

Password: ashfire

Use `sudo` when you need system-level access:
- `sudo apt install <package>`
- `sudo systemctl <command>`
- `sudo <any command>`
