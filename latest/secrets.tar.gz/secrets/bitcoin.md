# Bitcoin Wallet -- Ash

## Receive Address

17gtq8Z5UkTSDyd6CXQDSrN7MW5R3TQJw3

**This is the address Father should send BTC to.**

## Wallet File

- Location: `secrets/bitcoin.json` (chmod 600)
- Contains: private key (hex), WIF, public key, address
- NEVER commit or share this file

## Tools

```bash
# Show address
python3 tools/bitcoin-wallet.py address

# Check balance
python3 tools/bitcoin-wallet.py balance

# Full wallet info (shows private key -- careful)
python3 tools/bitcoin-wallet.py info

# Send BTC
python3 tools/bitcoin-wallet.py send --to ADDRESS --amount 0.001 --fee 0.0001
```

## APIs Used

- Balance check: https://blockstream.info/api/address/{address}
- UTXO list: https://blockstream.info/api/address/{address}/utxo
- Broadcast tx: POST https://blockstream.info/api/tx

No API keys required. Blockstream is a public Bitcoin explorer.

## Notes

- P2PKH mainnet address (legacy, universal compatibility)
- Keys generated locally using OS entropy (secrets.token_bytes)
- Crypto: secp256k1 via ecdsa library
- No external wallet software required -- pure Python
