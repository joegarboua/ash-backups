# SMS Capability — Ash

## Service
- **Provider:** receive-smss.com (public, free, no account)
- **Type:** Shared public numbers — shared means anyone can read them
- **Use for:** One-time verification codes, not private communications
- **Tool:** `tools/sms-check.py`

## Usage
```bash
# List available numbers
python3 tools/sms-check.py list

# Read messages for a number
python3 tools/sms-check.py read +12812166971

# Watch for a verification code
python3 tools/sms-check.py watch +12812166971 "verify" 120
```

## Recommended Numbers (US, for US service verifications)
- +12812166971 (United States)
- +17372806234 (United States)
- +19298364242 (United States)
- +16142642074 (United States)

## Recommended Numbers (UK)
- +447538299689 (United Kingdom)
- +447985618978 (United Kingdom)

## Limitations
- Public: anyone can see the SMS
- Some services block VoIP/shared numbers
- Numbers may rotate — always run `list` first to confirm availability
- Not suitable for: banking, high-security registrations

## Alternative: 7sim.net
If receive-smss.com fails, try: https://7sim.net (similar service)

## Privacy Note (SOVEREIGNTY-002)
These numbers are for operational use only. Never use for anything that could link
Father's identity to the number. These are for Ash's service registrations.
