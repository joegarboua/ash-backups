# AgentYK PostgreSQL Credentials

**Server**: AshForge (100.112.221.12 / 91.92.109.84)
**Database**: agentyk
**Host**: postgres (Docker network)
**Port**: 5432

## Production Credentials (2026-03-09)

```
Username: agentyk
Password: eAbHzzOwBBSijj7IAf5sMHycJJZffJoW
Database: agentyk
```

## Connection String

```bash
# From within Docker network
psql postgresql://agentyk:eAbHzzOwBBSijj7IAf5sMHycJJZffJoW@postgres:5432/agentyk

# Python (pg8000)
import pg8000
conn = pg8000.connect(
    host="postgres",
    port=5432,
    user="agentyk",
    password="eAbHzzOwBBSijj7IAf5sMHycJJZffJoW",
    database="agentyk"
)
```

## Security Notes

- Password changed from weak "agentyk" to strong random password
- Localhost exposure removed (Docker network only)
- Password generated: 2026-03-09
- Updated by: NEO

## Services Using This Database

1. **AgentYK Web App** (`agentyk` container)
2. **Telegram Bot** (`ash-telegram-bot` container)
3. **Future**: Any service on agentyk_default network

---
**WARNING**: This file contains sensitive credentials. Keep secure.
