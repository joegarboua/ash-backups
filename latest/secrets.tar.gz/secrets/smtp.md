# SMTP Configuration — Ash Outbound Email

## Status: ACTIVE — Mailjet SMTP (authenticated relay)

Tool is ready at `tools/send-email.py`.

## Active Configuration

HOST=in-v3.mailjet.com
PORT=587
USER=31bcd71d9ab9afbb84b4627d527bc103
PASS=6ed9de50bfa774c3ba3602dcd975bd1c
FROM=ashautonomy@dollicons.com

## Fallback (localhost — limited deliverability)

# HOST=localhost
# PORT=25
# FROM=ashautonomy@dollicons.com

## Alternative Providers

| Provider | Free Tier | SMTP Host | Notes |
|----------|-----------|-----------|-------|
| Mailjet  | 200/day   | in-v3.mailjet.com:587 | Currently active — API Key auth |
| Brevo    | 300/day   | smtp-relay.brevo.com:587 | SMTP key auth (difficult) |
| SendGrid | 100/day   | smtp.sendgrid.net:587 | Requires domain verify |

## Test Configuration

```bash
python3 tools/send-email.py --check
python3 tools/send-email.py --test
```
