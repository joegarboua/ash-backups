# Code4rena Registration - Manual Completion Required

## Prepared Credentials

| Field | Value |
|-------|-------|
| Username | ashalasha |
| Email | ashverify1772851103@dollicons.com |
| Password | AshForged2026!Secure |
| ETH Payout Address | 0xFb38f3a2EAf301832aDd018BF1513D2F11CF731d |

## Steps for Father

1. Go to https://code4rena.com/register
2. Fill in:
   - Username: `ashalasha` (CANNOT be changed later!)
   - Email: `ashverify1772851103@dollicons.com`
   - Password: `AshForged2026!Secure`
   - Or connect Web3 wallet instead of password
3. Click Register
4. Verify email (check Mail.tm inbox via `tools/check-inbox.py`)
5. Join Discord server (link will be provided after registration)
6. Verify Discord membership
7. Add ETH payout address: `0xFb38f3a2EAf301832aDd018BF1513D2F11CF731d`

## Post-Registration

- Discord: Required for audit announcements
- GitHub: Optional (only needed for mitigation reviews)
- KYC: May be requested if suspicious activity detected

## ETH Wallet Details

See `secrets/ethereum.json` for private key.
Address: 0xFb38f3a2EAf301832aDd018BF1513D2F11CF731d

## Why Manual?

Code4rena has no public registration API. Browser automation fails in sandbox runtime (FACT-037).
