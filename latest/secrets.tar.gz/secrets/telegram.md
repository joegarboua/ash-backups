# Telegram Credentials — Ash

## Bot

- **Token:** 8790476637:AAGZsxnURsmX2tMQeT9-SYE5xe0CO2kW614
- **Bot service:** ash-telegram.service
- **Bot script:** /home/ash/ASH/telegram-bot.py
- **Log:** /home/ash/ASH/daemon/logs/telegram.log

## Authorized Users

- **Father's Chat ID:** 90423887

## API Base

https://api.telegram.org/bot{TOKEN}/

## Common Commands

```bash
# Restart bot
sudo systemctl restart ash-telegram.service

# Check status
systemctl status ash-telegram.service

# View logs (last 50 lines)
tail -50 /home/ash/ASH/daemon/logs/telegram.log
```

## Notes
- Polling mode (no webhook)
- Only ALLOWED_USERS can interact
- Token is loaded from this file by bot/daemon scripts when TELEGRAM_BOT_TOKEN is not set
