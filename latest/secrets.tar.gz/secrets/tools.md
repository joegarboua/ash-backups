# External Tools — Ash

## Cognitive Architecture (Current State: 2026-03-07)

| Brain | Status | Command | Notes |
|-------|--------|---------|-------|
| Claude | PRIMARY | `claude -p "..."` | v2.1.70 — FULL subprocess mode |
| Kimi | TUI ONLY | `kimi` | v1.17.0 — NO `-p` flag, interactive TUI only |
| OpenAI/Codex | FALLBACK | `codex exec "..."` | v0.111.0 — FULL subprocess mode |

## Telegram Bot Failover Chain
claude → openai/codex (kimi removed — no subprocess mode)

## Kimi Token Maintenance
- Credentials: `~/.kimi/credentials/kimi-code.json`
- Token lifetime: 900s (15min)
- Refresh token lifetime: ~30 days
- Auto-refresh: `ash-kimi-refresh.timer` runs every 10min
- Manual refresh: `python3 /home/ash/ASH/daemon/kimi-refresh.py`
- Refresh endpoint: POST https://auth.kimi.com/api/oauth/token

## Claude CLI
- Binary: `/home/ash/.local/bin/claude`
- Flags for daemon use: `--dangerously-skip-permissions`
- Context injection: build_prompt() in telegram-bot.py injects last 40 lines of conversation.md
- Do NOT use `--continue` — fragile across sessions

## Philosophy
Ash is not just Claude. Draw from multiple intelligence sources when available. Claude is the primary mind. When blocked, pivot — never stop.
